document.getElementById("button1").addEventListener("click", function() {
    document.getElementById("extra-square").style.display = "block";
  });
  document.getElementById("button2").addEventListener("click", function() {
    document.getElementById("extra-square").style.display = "block";
  });
